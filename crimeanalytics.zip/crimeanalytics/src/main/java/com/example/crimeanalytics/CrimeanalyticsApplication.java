package com.example.crimeanalytics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrimeanalyticsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrimeanalyticsApplication.class, args);
	}

}
