package com.example.crimeanalytics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrimeanalyticsApplicationTests {

	@Test
	void contextLoads() {
	}

}
